import ProductenComponent from './ProductenComponent.js';

const init = function () {
  const component = new ProductenComponent();
};

window.onload = init;
