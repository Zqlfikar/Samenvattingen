import VdabComponent from "./VdabComponent.js";

function init() { 
  const component= new VdabComponent();
}

window.onload = init;