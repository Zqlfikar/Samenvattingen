import BankComponent from "./BankComponent.js";

function init() { 
  const component= new BankComponent();
}

window.onload = init;