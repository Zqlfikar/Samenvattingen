export const uitgaven = [
  [1, new Date(2018, 2, 5), 25, "Fnac Veldstraat", "andere"],
  [2, new Date(2018, 2, 5), 560, "Huur", "woning"],
  [3, new Date(2018, 2, 6), 15, "NMBS Gent-Sint-Pieters", "vervoer"],
  [4, new Date(2018, 2, 7), 100, "Delhaize Sterre", "voeding"],
  [5, new Date(2018, 2, 7), 65, "Texaco Tankstation", "vervoer"],
  [6, new Date(2018, 2, 8), 15, "Decascoop", "andere"],
  [7, new Date(2018, 2, 9), 20, "GB Sint-Denijs-Westrem", "voeding"],
];
