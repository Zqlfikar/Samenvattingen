import BoekenComponent from "./BoekenComponent.js";


function init() { 
  const component= new BoekenComponent();
}

window.onload = init;