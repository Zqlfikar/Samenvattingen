import AfrikaansDobbelenComponent from "./AfrikaansDobbelenComponent.js";

function init() {
  const component = new AfrikaansDobbelenComponent();
}

window.onload = init;
