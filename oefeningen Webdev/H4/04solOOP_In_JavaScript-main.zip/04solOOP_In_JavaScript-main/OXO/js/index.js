import OxoComponent from './OxoComponent3.js';

function init() {
  const component = new OxoComponent();
}

window.onload = init;
