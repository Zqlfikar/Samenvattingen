import { initialiseerScrabble } from "./scrabble.js";

const init = () => {
  initialiseerScrabble();
};

window.onload = init;
