import { initialiseerCraps } from "./craps.js";

function init() {
  initialiseerCraps();
}

window.onload = init;
