import { greetUser } from "./irock.js";

function init() {
  greetUser();
}

window.onload = init;
