function sayHi(user) {
  console.log(`Hello, ${user}!`);
}
