import GefietsteKilometersComponent from "./GefietsteKilometersComponent.js";

function init() {
  new GefietsteKilometersComponent();
}

window.onload = init;
