import OxoComponent from './OxoComponent.js';

function init() {
  const component = new OxoComponent();
}

window.onload = init;
