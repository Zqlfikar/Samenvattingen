## Oefeningen Hoofdstuk 05 - Functioneel Programmeren en Collections

## Modeloplossingen
