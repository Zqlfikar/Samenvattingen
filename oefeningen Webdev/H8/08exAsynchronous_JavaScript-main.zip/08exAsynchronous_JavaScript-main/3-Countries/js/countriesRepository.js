class CountriesRepository {
  #countries = [];

  get countries() {
    return this.#countries;
  }

  addCountry(name, capital, region, flag) {

  }

  filteredCountries(searchString) {

  }
}
