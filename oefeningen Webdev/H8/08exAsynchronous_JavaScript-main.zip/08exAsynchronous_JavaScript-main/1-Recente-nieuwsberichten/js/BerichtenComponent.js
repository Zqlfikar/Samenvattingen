import Bericht from './Bericht.js';

export default class BerichtenComponent {
  #url;
  constructor() {
      //'https://data.stad.gent/api/records/1.0/search/?dataset=recente-nieuwsberichten-van-stadgent&q=&rows=5';
      
  }
  #getData(){}
  #berichtenToHTML(berichten) {}
}
