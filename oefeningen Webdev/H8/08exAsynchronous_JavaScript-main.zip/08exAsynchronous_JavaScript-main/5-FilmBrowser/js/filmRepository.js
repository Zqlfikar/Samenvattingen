import { Film } from './film.js';

export class FilmRepository {
  #films = [];

  get films() {
    return this.#films;
  }

  addFilms(arrFilms) {
    // TODO
  }

  addDetail(id, objDetail) {
    // TODO
  }
  getFilmById(id) {
    // TODO
  }
}
