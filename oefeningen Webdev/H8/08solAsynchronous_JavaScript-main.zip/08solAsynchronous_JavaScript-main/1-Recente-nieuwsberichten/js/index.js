import BerichtenComponent from './BerichtenComponent.js';

window.onload = () => {
  new BerichtenComponent();
};
