import FilmComponent from './FilmComponent.js';

window.onload = () => {
  new FilmComponent();
};
