import CountriesComponent from './CountriesComponent.js';

window.onload = () => {
  new CountriesComponent();
};
