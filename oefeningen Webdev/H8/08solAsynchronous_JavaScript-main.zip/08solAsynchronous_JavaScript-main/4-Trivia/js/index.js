import TriviaComponent from './triviaComponent.js'

window.onload = ()=>{new TriviaComponent()}